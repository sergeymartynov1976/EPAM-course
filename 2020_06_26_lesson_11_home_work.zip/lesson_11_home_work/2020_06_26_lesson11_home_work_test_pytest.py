#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pytest

from even_filter import get_even_list_comprehension as ge

def test_positive():
    VAL_1 = [
    [[10, 11, 12], [13, 14, 15], [16, 17, 18]],
    [[19, 20, 21], [22, 23, 24], [25, 26, 27]],
    [[28, 29, 30], [31, 32, 33], [34, 35, 36]],]
    assert ge(VAL_1) == [10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36]
    
def test_negative_1():
    VAL_2 = [[28, 29, 30], [31, 32, 33], [34, 35, 36]]
    with pytest.raises(TypeError) as e:
        ge(VAL_2)
    assert str(e.value) == "'int' object is not iterable"
    
def test_negative_2():
    VAL_3 = [["asdfr", [31, 32, 33], [34, 35, 36]]]
    with pytest.raises(TypeError) as e:
        ge(VAL_3)
    assert str(e.value) == "not all arguments converted during string formatting"

