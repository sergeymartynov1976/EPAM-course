#!/usr/bin/env python
# coding: utf-8

# In[1]:


from typing import Generator
from typing import List

'''Function to filter even numbers from list of lists'''

def get_even_list_comprehension(values: List) -> List[int]:
    """Return all even numbers in ONE LINE using list comprehension.
    :param values: input list of lists with values
    :return: list with int values
    """
    return [e for v in values for l in v for e in l if e%2==0]

